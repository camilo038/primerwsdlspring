package snippet;

public class Snippet {
	public static void main(String[] args) {
		<plugin>
						<groupId>org.apache.cxf</groupId>
						<artifactId>cxf-codegen-plugin</artifactId>
						<version>3.2.1</version>
						<executions>
							<execution>
								<id>generate-sources</id>
								<phase>generate-sources</phase>
								<configuration>
									<sourceRoot>${project.build.directory}/generated/cxf</sourceRoot>
									<wsdlOptions>
										<wsdlOption>
											<wsdl>${basedir}/src/main/resources/CustomerOrders.wsdl</wsdl>
											<wsdlLocation>classpath:CustomerOrders.wsdl</wsdlLocation>
										</wsdlOption>
									</wsdlOptions>
								</configuration>
								<goals>
									<goal>wsdl2java</goal>
								</goals>
							</execution>
						</executions>
					</plugin>
	}
}

