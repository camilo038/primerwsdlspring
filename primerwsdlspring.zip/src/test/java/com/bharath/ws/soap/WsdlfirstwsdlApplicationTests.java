package com.bharath.ws.soap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsdlfirstwsdlApplicationTests {

	@Test
	void contextLoads() {
	}

}
